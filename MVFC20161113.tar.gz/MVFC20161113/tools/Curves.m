%% run the curves in the  paper
exp2_2(); % fig3
exp3_3(); % fig7
exp3_6(); % fig11